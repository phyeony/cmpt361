// Refered https://github.com/davidwparker/programmingtil-webgl for various drawings
// Refered https://webglfundamentals.org/webgl/lessons
// Refered https://learnopengl.com/Lighting/Multiple-lights
// https://www.cs.toronto.edu/~jacobson/phong-demo/
// https://stackoverflow.com/questions/38070899/how-to-interpolate-normals-for-phong-shading-in-opengl

h)   gl.enable(gl.CULL_FACE); and other colour param as been tuned


e) Was almost done with spot lighting, but couldn't finish it.